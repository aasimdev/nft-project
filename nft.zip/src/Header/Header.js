
import React from 'react'
import { Container, Nav, Navbar, Image, Button } from 'react-bootstrap'
import Logo from '../assets/img/Logo.png'

const Header = () => {

    return (
        <Navbar expand="lg" fixed="top">
            <Container>
                <Navbar.Brand href="#home"><Image src={Logo} /></Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ms-auto">
                        <Nav.Link href="#">About</Nav.Link>
                        <Nav.Link href="#">NFT Member</Nav.Link>
                    </Nav>
                    <Button variant="primary">Sign UP/Login</Button>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    )
}

export default Header